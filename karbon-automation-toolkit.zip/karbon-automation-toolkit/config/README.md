# Layer 2 Config (placeholder)

This directory is where workflow-specific configuration goes once your
firm's workflow redesign is finalized. It's intentionally empty except for
this README — nothing here should be written until the redesign lands
(see Section 6, "Hold Until Workflows Are Finalized," in the spec).

Expected contents once populated:

- `checklists/` — one file per return type (e.g. `1040.json`, `1120s.json`),
  each a list of explicit checkable items. This is the one piece safe to
  draft *before* the redesign finishes, since it's about document
  requirements, not Karbon configuration — see spec Section 5.
- `status_rules.json` — the trigger → action mapping described in spec
  Section 3.1 (which Karbon status/event maps to which toolkit calls).
- `templates.json` — mapping from situation (e.g. "missing_documents",
  "response_reminder") to Karbon draft template ID and its placeholder names.
- `escalation_policy.json` — response-timeout thresholds per situation,
  holiday calendar, and any deadline-proximity adjustments.

Example shape for `checklists/1040.json` (illustrative only):

```json
{
  "return_type": "1040",
  "items": [
    "Signed engagement letter on file",
    "Organizer returned with all sections completed",
    "W-2 count matches count indicated in organizer",
    "1099s received for all sources listed in organizer",
    "K-1 received for each entity listed in organizer",
    "Prior-year return on file (new clients only)"
  ]
}
```

Example shape for `status_rules.json` (illustrative only — status names are
placeholders until finalized):

```json
{
  "rules": [
    {
      "trigger": "karbon.work_item_status_changed",
      "condition": { "new_status": "Documents Received" },
      "action": "run_completeness_check",
      "checklist_ref": "checklists/1040.json"
    }
  ]
}
```
