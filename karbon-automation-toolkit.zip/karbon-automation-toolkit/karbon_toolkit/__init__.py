"""
karbon_toolkit — Layer 1 core toolkit for the client workflow automation agent.

This package contains workflow-agnostic connectors and utilities:
- karbon_client:   Karbon API wrapper (work items, drafts, webhooks)
- graph_client:    Microsoft Graph calendar wrapper
- ignition_client: Ignition webhook handling + client matching
- claude_client:   Document completeness checks + draft content generation
- scheduler:       Generic time-in-status / overdue escalation engine

None of these modules should contain workflow-specific logic (status names,
checklist content, template IDs). That belongs in Layer 2 config, loaded
and applied by the orchestrator (see orchestrator.py).
"""

__version__ = "0.1.0"
