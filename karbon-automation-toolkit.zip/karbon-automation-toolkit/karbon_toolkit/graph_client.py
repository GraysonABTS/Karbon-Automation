"""
graph_client.py

Wrapper around Microsoft Graph's calendar endpoints for scheduling preparer
work blocks in Outlook. Layer 1 — generic actions only; the orchestrator/
Layer 2 decides when and for whom to call these.

Auth uses MSAL (OAuth2 client credentials or on-behalf-of, depending on
whether the app needs to act as itself or as specific preparers). Client
credentials flow is simplest if a shared mailbox/service account model
works for your firm; delegated auth is needed if events must be created
directly on each preparer's own calendar under their identity.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Optional

import requests

try:
    import msal
except ImportError:  # pragma: no cover
    msal = None  # msal is only required if using the token helper below

logger = logging.getLogger(__name__)

GRAPH_API_BASE = "https://graph.microsoft.com/v1.0"


class GraphAPIError(Exception):
    """Raised when the Graph API returns an unrecoverable error."""


@dataclass
class GraphCredentials:
    tenant_id: str
    client_id: str
    client_secret: str
    scopes: tuple = ("https://graph.microsoft.com/.default",)


class GraphTokenProvider:
    """Handles OAuth2 client-credentials token acquisition and caching via MSAL."""

    def __init__(self, credentials: GraphCredentials):
        if msal is None:
            raise ImportError("msal is required for GraphTokenProvider — pip install msal")
        self.credentials = credentials
        self._app = msal.ConfidentialClientApplication(
            client_id=credentials.client_id,
            client_credential=credentials.client_secret,
            authority=f"https://login.microsoftonline.com/{credentials.tenant_id}",
        )

    def get_token(self) -> str:
        result = self._app.acquire_token_silent(list(self.credentials.scopes), account=None)
        if not result:
            result = self._app.acquire_token_for_client(scopes=list(self.credentials.scopes))
        if "access_token" not in result:
            raise GraphAPIError(f"Failed to acquire Graph token: {result.get('error_description')}")
        return result["access_token"]


class GraphCalendarClient:
    """
    Generic calendar operations. `preparer_user_id` is the Graph user ID or
    userPrincipalName (email) of the preparer whose calendar is being modified —
    passed in by the caller, never hardcoded here.
    """

    def __init__(self, token_provider: GraphTokenProvider,
                 base_url: str = GRAPH_API_BASE,
                 session: Optional[requests.Session] = None):
        self.token_provider = token_provider
        self.base_url = base_url.rstrip("/")
        self.session = session or requests.Session()

    def _headers(self) -> dict:
        return {
            "Authorization": f"Bearer {self.token_provider.get_token()}",
            "Content-Type": "application/json",
        }

    def _request(self, method: str, path: str, **kwargs):
        url = f"{self.base_url}{path}"
        response = self.session.request(method, url, headers=self._headers(), **kwargs)
        if response.status_code >= 400:
            raise GraphAPIError(
                f"Graph API error {response.status_code} on {method} {path}: {response.text}"
            )
        if response.status_code == 204 or not response.content:
            return None
        return response.json()

    def create_calendar_block(self, preparer_user_id: str, subject: str,
                               start_iso: str, end_iso: str,
                               timezone: str = "America/Los_Angeles",
                               body_text: str = "") -> dict:
        payload = {
            "subject": subject,
            "body": {"contentType": "text", "content": body_text},
            "start": {"dateTime": start_iso, "timeZone": timezone},
            "end": {"dateTime": end_iso, "timeZone": timezone},
        }
        return self._request("POST", f"/users/{preparer_user_id}/events", json=payload)

    def move_calendar_block(self, preparer_user_id: str, event_id: str,
                             new_start_iso: str, new_end_iso: str,
                             timezone: str = "America/Los_Angeles") -> dict:
        payload = {
            "start": {"dateTime": new_start_iso, "timeZone": timezone},
            "end": {"dateTime": new_end_iso, "timeZone": timezone},
        }
        return self._request(
            "PATCH", f"/users/{preparer_user_id}/events/{event_id}", json=payload
        )

    def delete_calendar_block(self, preparer_user_id: str, event_id: str) -> None:
        self._request("DELETE", f"/users/{preparer_user_id}/events/{event_id}")
