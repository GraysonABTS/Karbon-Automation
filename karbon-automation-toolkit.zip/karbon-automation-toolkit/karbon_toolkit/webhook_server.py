"""
webhook_server.py

Lightweight receiver for inbound webhooks (Ignition proposal.accepted,
Karbon work item/custom field changes). This is intentionally thin: it
validates and normalizes the incoming event, then hands off to a rule
dispatcher that will live in Layer 2 config once your workflows are
finalized.

Run with: uvicorn karbon_toolkit.webhook_server:app --reload

NOTE: This is a scaffold for local development. Before production use,
add: webhook signature verification (both Ignition and Karbon support
this), request logging appropriate for PII-containing payloads, and
proper secrets management for the credentials wired up in main.py.
"""

from __future__ import annotations

import logging
from typing import Optional

from fastapi import FastAPI, Request, HTTPException

from karbon_toolkit.ignition_client import parse_proposal_accepted_payload

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="Karbon Automation Agent - Webhook Receiver")

# Layer 2 will register handlers here at startup (see rule_dispatcher stub
# below). Left as a simple list for now — swap for whatever rule-matching
# structure Layer 2 config ends up using (see spec Section 3.1).
_registered_handlers: list = []


def register_handler(event_type: str, handler) -> None:
    """Layer 2 config calls this at startup to wire up its rules."""
    _registered_handlers.append((event_type, handler))


@app.post("/webhooks/ignition")
async def handle_ignition_webhook(request: Request):
    payload = await request.json()
    logger.info("Received Ignition webhook: proposal_id=%s", payload.get("proposal_id", payload.get("id")))

    try:
        event = parse_proposal_accepted_payload(payload)
    except Exception as exc:
        logger.exception("Failed to parse Ignition payload")
        raise HTTPException(status_code=400, detail=f"Malformed payload: {exc}")

    for event_type, handler in _registered_handlers:
        if event_type == "ignition.proposal_accepted":
            handler(event)

    return {"status": "received"}


@app.post("/webhooks/karbon")
async def handle_karbon_webhook(request: Request):
    payload = await request.json()
    event_type = payload.get("EventType", "unknown")
    logger.info("Received Karbon webhook: event_type=%s", event_type)

    for registered_type, handler in _registered_handlers:
        if registered_type == f"karbon.{event_type}":
            handler(payload)

    return {"status": "received"}


@app.get("/health")
async def health() -> dict:
    return {"status": "ok"}
