"""
scheduler.py

Generic "time-in-status" escalation engine. This is the single most reused
piece of Layer 1 — it powers Workflow C (client response timeouts) as well
as the additional candidates from Section 9 of the spec (review bottleneck
escalation, extension risk flagging). None of those specifics live here;
this module just answers "has item X been in state Y for longer than N
business days?" and hands back what's overdue for the caller to act on.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime, timedelta, date
from typing import Callable, Optional

logger = logging.getLogger(__name__)


def is_business_day(d: date, holidays: Optional[set[date]] = None) -> bool:
    holidays = holidays or set()
    return d.weekday() < 5 and d not in holidays  # Mon-Fri, not a holiday


def add_business_days(start: date, days: int, holidays: Optional[set[date]] = None) -> date:
    """Adds N business days to a date, skipping weekends and the given holidays."""
    current = start
    remaining = days
    step = 1 if days >= 0 else -1
    remaining = abs(days)
    while remaining > 0:
        current += timedelta(days=step)
        if is_business_day(current, holidays):
            remaining -= 1
    return current


def business_days_between(start: date, end: date, holidays: Optional[set[date]] = None) -> int:
    """Counts business days elapsed between two dates (end - start), skipping weekends/holidays."""
    if end < start:
        return -business_days_between(end, start, holidays)
    count = 0
    current = start
    while current < end:
        current += timedelta(days=1)
        if is_business_day(current, holidays):
            count += 1
    return count


@dataclass
class WatchedItem:
    """
    A generic thing being watched for overdue status. `item_id` and
    `entered_status_at` come from Karbon (or wherever); `context` is a
    free-form dict the caller can use to carry whatever it needs to act
    on the item later (work item ID, client email, current status name, etc).
    """
    item_id: str
    entered_status_at: datetime
    context: dict


@dataclass
class OverdueItem:
    item: WatchedItem
    business_days_elapsed: int


def find_overdue_items(
    watched_items: list[WatchedItem],
    threshold_business_days: int,
    now: Optional[datetime] = None,
    holidays: Optional[set[date]] = None,
) -> list[OverdueItem]:
    """
    Given a list of items and how long ago each entered its current status,
    returns those that have exceeded the threshold. Caller decides what
    "entered this status" means (e.g. client task sent, work item moved to
    In Review) and supplies `watched_items` accordingly — this function is
    agnostic to what kind of status is being watched.
    """
    now = now or datetime.utcnow()
    overdue = []
    for item in watched_items:
        elapsed = business_days_between(item.entered_status_at.date(), now.date(), holidays)
        if elapsed >= threshold_business_days:
            overdue.append(OverdueItem(item=item, business_days_elapsed=elapsed))
    return overdue


def run_escalation_check(
    fetch_watched_items: Callable[[], list[WatchedItem]],
    threshold_business_days: int,
    on_overdue: Callable[[OverdueItem], None],
    holidays: Optional[set[date]] = None,
) -> int:
    """
    Orchestration helper meant to be called on a schedule (cron/timer).

    `fetch_watched_items`: a Layer-2-supplied function that queries Karbon
        (or elsewhere) for the current set of items in the status being
        watched, e.g. "all work items with an unanswered Client Request."
    `on_overdue`: a Layer-2-supplied callback that does whatever should
        happen for each overdue item (draft a follow-up, reschedule, flag
        a reviewer, etc.) — this function has no opinion on what that is.

    Returns the count of overdue items processed, for logging/monitoring.
    """
    watched = fetch_watched_items()
    overdue = find_overdue_items(watched, threshold_business_days, holidays=holidays)
    logger.info("Escalation check: %d/%d items overdue (threshold=%d business days)",
                len(overdue), len(watched), threshold_business_days)
    for overdue_item in overdue:
        try:
            on_overdue(overdue_item)
        except Exception:
            logger.exception("on_overdue callback failed for item_id=%s", overdue_item.item.item_id)
    return len(overdue)
