"""
claude_client.py

Generic Claude-powered functions used across workflows:
- check_document_completeness: given documents + a checklist (data, not
  hardcoded), returns what's present/missing.
- draft_fill_values: given context about a situation, generates the specific
  text to drop into a Karbon draft template's placeholders.

Both functions take the checklist/template content as arguments — this file
contains no return-type-specific or firm-specific content. That lives in
Layer 2 config (see config/checklists/ and config/templates/ once populated).
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from typing import Optional

import anthropic

logger = logging.getLogger(__name__)

DEFAULT_MODEL = "claude-sonnet-4-6"


@dataclass
class CompletenessResult:
    is_complete: bool
    present_items: list = field(default_factory=list)
    missing_items: list = field(default_factory=list)
    ambiguous_items: list = field(default_factory=list)  # e.g. illegible docs — flag for human review
    raw_response: str = ""


class ClaudeWorkflowClient:
    def __init__(self, api_key: Optional[str] = None, model: str = DEFAULT_MODEL):
        self.client = anthropic.Anthropic(api_key=api_key) if api_key else anthropic.Anthropic()
        self.model = model

    def check_document_completeness(self, checklist: list[str],
                                     document_texts: list[str],
                                     context: str = "") -> CompletenessResult:
        """
        checklist: explicit list of checkable items, e.g.
            ["Signed engagement letter on file",
             "All organizer sections completed",
             "W-2 count matches organizer",
             "K-1 received for each entity listed in organizer"]
        document_texts: extracted text content of the documents received
            (extraction from PDFs/images happens upstream of this function —
            this module only reasons over already-extracted text).
        context: optional free text with return-type or client-specific notes.

        Returns a CompletenessResult. Ambiguous items (e.g. an illegible or
        partially-visible document) are surfaced separately rather than
        being silently marked missing or present — per the "flag for human
        review rather than guess" principle from the spec's open questions.
        """
        system_prompt = (
            "You are reviewing tax preparation documents against a checklist "
            "for a CPA/EA firm's internal workflow. For each checklist item, "
            "determine whether it is clearly satisfied by the provided documents, "
            "clearly missing, or ambiguous (e.g. a document is present but illegible "
            "or incomplete in a way that needs human judgment). "
            "Respond ONLY with valid JSON in this exact shape, no other text: "
            '{"present": ["item", ...], "missing": ["item", ...], "ambiguous": ["item", ...]}'
        )

        user_content = (
            f"Checklist items:\n{json.dumps(checklist, indent=2)}\n\n"
            f"Additional context: {context or '(none)'}\n\n"
            f"Document text extracted from {len(document_texts)} document(s):\n\n"
            + "\n\n---\n\n".join(document_texts)
        )

        response = self.client.messages.create(
            model=self.model,
            max_tokens=1500,
            system=system_prompt,
            messages=[{"role": "user", "content": user_content}],
        )

        raw_text = "".join(block.text for block in response.content if hasattr(block, "text"))

        try:
            parsed = json.loads(raw_text)
        except json.JSONDecodeError:
            logger.error("Failed to parse completeness check response as JSON: %s", raw_text)
            # Fail safe: treat everything as ambiguous rather than guessing complete/incomplete.
            return CompletenessResult(
                is_complete=False,
                ambiguous_items=list(checklist),
                raw_response=raw_text,
            )

        missing = parsed.get("missing", [])
        ambiguous = parsed.get("ambiguous", [])
        return CompletenessResult(
            is_complete=(not missing and not ambiguous),
            present_items=parsed.get("present", []),
            missing_items=missing,
            ambiguous_items=ambiguous,
            raw_response=raw_text,
        )

    def draft_fill_values(self, template_placeholders: list[str],
                           client_name: str,
                           situation_context: str,
                           missing_items: Optional[list[str]] = None) -> dict:
        """
        Generates the specific text for each placeholder in a Karbon draft
        template. `template_placeholders` are the placeholder names/keys
        the template expects (e.g. ["client_first_name", "missing_items_list",
        "requested_by_date"]); this function returns a dict mapping each to
        generated content.

        This does NOT decide which template to use — that's a Layer 2 rule.
        It only fills in the content of a template it's told to fill.
        """
        system_prompt = (
            "You are drafting fill-in content for an existing email template "
            "used by a CPA/EA tax firm. Write in a professional, warm, and "
            "concise tone appropriate for client communication. Do not invent "
            "information not provided in the context. "
            "Respond ONLY with valid JSON mapping each requested placeholder "
            "name to its generated text content, no other text."
        )

        user_content = (
            f"Client name: {client_name}\n"
            f"Situation context: {situation_context}\n"
            f"Missing items (if applicable): {missing_items or []}\n\n"
            f"Placeholders to fill: {json.dumps(template_placeholders)}"
        )

        response = self.client.messages.create(
            model=self.model,
            max_tokens=800,
            system=system_prompt,
            messages=[{"role": "user", "content": user_content}],
        )

        raw_text = "".join(block.text for block in response.content if hasattr(block, "text"))

        try:
            return json.loads(raw_text)
        except json.JSONDecodeError:
            logger.error("Failed to parse draft fill values response as JSON: %s", raw_text)
            # Fail safe: return empty fills rather than guessed content going into a client email.
            return {ph: "" for ph in template_placeholders}
