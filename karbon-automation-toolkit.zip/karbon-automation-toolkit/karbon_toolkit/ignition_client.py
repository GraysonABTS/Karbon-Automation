"""
ignition_client.py

Handles inbound events from Ignition (the accounting proposal/engagement
e-sign tool — not the SCADA product of the same name). Layer 1 — generic
event parsing and client-matching only; what to *do* with a signed
engagement is a Layer 2 rule.

Two integration paths, in order of preference:
1. Native Ignition webhook (if enabled on your Ignition plan) posting
   directly to an endpoint this service exposes.
2. Zapier "Proposal Accepted" trigger forwarding to the same endpoint via
   Zapier's Webhooks action, if native webhooks aren't available/enabled.

Either way, the payload shape should be confirmed against what actually
arrives in practice — treat the parsing below as a starting point to
validate against a real test event, not a guaranteed final schema.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Optional

logger = logging.getLogger(__name__)


@dataclass
class SignedEngagementEvent:
    client_email: str
    client_name: str
    proposal_id: str
    signed_at: str
    raw_payload: dict


def parse_proposal_accepted_payload(payload: dict) -> SignedEngagementEvent:
    """
    Normalizes an Ignition (or Zapier-forwarded Ignition) webhook payload
    into a SignedEngagementEvent. Field names below are placeholders based
    on the documented `proposal.accepted` event shape — confirm exact keys
    against a real captured payload before relying on this in production.
    """
    client = payload.get("client", {})
    return SignedEngagementEvent(
        client_email=client.get("email", ""),
        client_name=client.get("name", ""),
        proposal_id=payload.get("proposal_id") or payload.get("id", ""),
        signed_at=payload.get("signed_at") or payload.get("accepted_at", ""),
        raw_payload=payload,
    )


def match_client_to_karbon_contact(event: SignedEngagementEvent, karbon_client) -> Optional[dict]:
    """
    Resolves an Ignition client to a Karbon contact using email address as
    the shared identifier. Returns the Karbon contact dict, or None if no
    match is found (in which case the orchestrator should flag for human
    review rather than guess).

    `karbon_client` is a KarbonClient instance (see karbon_client.py) —
    passed in rather than imported to keep this module's dependencies light
    and to make testing with a mock easier.
    """
    if not event.client_email:
        logger.warning("Signed engagement event has no client email; cannot match. proposal_id=%s",
                        event.proposal_id)
        return None

    contact = karbon_client.find_contact_by_email(event.client_email)
    if not contact:
        logger.warning("No Karbon contact found for email=%s (proposal_id=%s)",
                        event.client_email, event.proposal_id)
    return contact
