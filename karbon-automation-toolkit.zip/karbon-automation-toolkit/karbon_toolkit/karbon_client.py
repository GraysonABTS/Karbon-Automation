"""
karbon_client.py

Thin wrapper around the Karbon API. Layer 1 — generic actions only.
No status names, template IDs, or workflow logic here; those are passed
in as arguments by the Layer 2 rules / orchestrator.

Karbon API docs: https://developers.karbonhq.com/
Auth: requires both an `Authorization` bearer token/key and an `AccessKey`
header (per-user API key, generated in Karbon under user settings).
Rate limit: 120 requests/minute. This client backs off automatically on 429s.
"""

from __future__ import annotations

import time
import logging
from dataclasses import dataclass
from typing import Any, Optional

import requests

logger = logging.getLogger(__name__)

KARBON_API_BASE = "https://api.karbonhq.com/v3"


class KarbonAPIError(Exception):
    """Raised when the Karbon API returns an unrecoverable error."""


@dataclass
class KarbonCredentials:
    authorization_token: str  # value for the Authorization header
    access_key: str  # value for the AccessKey header


class KarbonClient:
    """
    Generic Karbon API client. Every method here is workflow-agnostic —
    callers supply the specific status name, template ID, etc.
    """

    def __init__(self, credentials: KarbonCredentials, base_url: str = KARBON_API_BASE,
                 max_retries: int = 5, session: Optional[requests.Session] = None):
        self.credentials = credentials
        self.base_url = base_url.rstrip("/")
        self.max_retries = max_retries
        self.session = session or requests.Session()

    # ------------------------------------------------------------------
    # Low-level request handling with 429 backoff
    # ------------------------------------------------------------------

    def _headers(self) -> dict:
        return {
            "Authorization": self.credentials.authorization_token,
            "AccessKey": self.credentials.access_key,
            "Content-Type": "application/json",
        }

    def _request(self, method: str, path: str, **kwargs) -> Any:
        url = f"{self.base_url}{path}"
        attempt = 0
        while True:
            attempt += 1
            response = self.session.request(method, url, headers=self._headers(), **kwargs)

            if response.status_code == 429:
                retry_after = int(response.headers.get("Retry-After", 2 ** attempt))
                if attempt > self.max_retries:
                    raise KarbonAPIError(
                        f"Rate limited on {method} {path} after {attempt} attempts"
                    )
                logger.warning(
                    "Karbon API rate limited (attempt %s), backing off %ss",
                    attempt, retry_after,
                )
                time.sleep(retry_after)
                continue

            if response.status_code >= 400:
                raise KarbonAPIError(
                    f"Karbon API error {response.status_code} on {method} {path}: {response.text}"
                )

            if response.status_code == 204 or not response.content:
                return None
            return response.json()

    # ------------------------------------------------------------------
    # Work items
    # ------------------------------------------------------------------

    def get_work_item(self, work_item_id: str) -> dict:
        return self._request("GET", f"/WorkItems/{work_item_id}")

    def list_work_items(self, odata_filter: Optional[str] = None,
                         top: int = 100, skip: int = 0) -> dict:
        params = {"$top": top, "$skip": skip}
        if odata_filter:
            params["$filter"] = odata_filter
        return self._request("GET", "/WorkItems", params=params)

    def update_work_item_status(self, work_item_id: str, status: str) -> dict:
        """Set a work item's status to any status name that exists in Karbon."""
        return self._request(
            "PATCH", f"/WorkItems/{work_item_id}", json={"WorkStatus": status}
        )

    def update_work_item_date(self, work_item_id: str, new_date_iso: str,
                               date_field: str = "StartDate") -> dict:
        """
        Reschedule a work item. `date_field` defaults to StartDate but can be
        set to DueDate or another Karbon date field depending on what your
        Layer 2 rules need to move.
        """
        return self._request(
            "PATCH", f"/WorkItems/{work_item_id}", json={date_field: new_date_iso}
        )

    def get_work_item_attachments(self, work_item_id: str) -> list:
        result = self._request("GET", f"/WorkItems/{work_item_id}/Attachments")
        return result.get("value", []) if result else []

    def download_attachment(self, attachment_url: str) -> bytes:
        """Attachment URLs are typically pre-signed; fetched directly, not via _request."""
        response = self.session.get(attachment_url, headers=self._headers())
        response.raise_for_status()
        return response.content

    # ------------------------------------------------------------------
    # Contacts / clients
    # ------------------------------------------------------------------

    def find_contact_by_email(self, email: str) -> Optional[dict]:
        result = self._request(
            "GET", "/Contacts", params={"$filter": f"BusinessCards/any(b: b/EmailAddress eq '{email}')"}
        )
        values = result.get("value", []) if result else []
        return values[0] if values else None

    # ------------------------------------------------------------------
    # Email drafts / scheduled send
    # ------------------------------------------------------------------
    #
    # NOTE: Karbon's exact draft/scheduled-send endpoints should be confirmed
    # against current API docs (developers.karbonhq.com) before this ships —
    # the shape below reflects the documented pattern (create against a
    # template, then patch to schedule) but field names may need adjustment.

    def create_draft_from_template(self, template_id: str, work_item_id: str,
                                    recipient_email: str, fill_values: dict) -> dict:
        """
        Populate an existing Karbon email draft template with recipient and
        fill-in values. Returns the created draft's ID for scheduling.
        `fill_values` keys should match the template's placeholder names.
        """
        payload = {
            "TemplateId": template_id,
            "WorkItemId": work_item_id,
            "RecipientEmail": recipient_email,
            "FillValues": fill_values,
        }
        return self._request("POST", "/EmailDrafts", json=payload)

    def schedule_draft_send(self, draft_id: str, send_at_iso: str) -> dict:
        """
        Schedule a draft for sending at a future time, giving the preparer
        a review window before it actually goes out. This is the mechanism
        that keeps a human in the loop — the agent never sends directly.
        """
        return self._request(
            "PATCH", f"/EmailDrafts/{draft_id}", json={"ScheduledSendAt": send_at_iso}
        )

    def cancel_scheduled_draft(self, draft_id: str) -> dict:
        return self._request("PATCH", f"/EmailDrafts/{draft_id}", json={"ScheduledSendAt": None})

    # ------------------------------------------------------------------
    # Webhooks
    # ------------------------------------------------------------------

    def subscribe_webhook(self, event_type: str, target_url: str) -> dict:
        """
        Subscribe to a Karbon webhook event (e.g. WorkItem changes,
        CustomField changes). Confirm current event type names against
        Karbon's webhook docs before use — the catalogue has been expanding.
        """
        return self._request(
            "POST", "/WebhookSubscriptions",
            json={"EventType": event_type, "TargetUrl": target_url},
        )

    def list_webhook_subscriptions(self) -> list:
        result = self._request("GET", "/WebhookSubscriptions")
        return result.get("value", []) if result else []
