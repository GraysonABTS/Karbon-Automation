"""
Tests for scheduler.py — the business-day math is the part most worth
verifying in isolation before it's driving real client follow-ups.
Run with: pytest tests/test_scheduler.py
"""

from datetime import date, datetime

from karbon_toolkit.scheduler import (
    is_business_day,
    add_business_days,
    business_days_between,
    find_overdue_items,
    WatchedItem,
)


def test_is_business_day_weekday():
    assert is_business_day(date(2026, 7, 1))  # Wednesday


def test_is_business_day_weekend():
    assert not is_business_day(date(2026, 7, 4))  # Saturday


def test_is_business_day_holiday():
    holidays = {date(2026, 7, 3)}  # Friday observed holiday
    assert not is_business_day(date(2026, 7, 3), holidays)


def test_add_business_days_skips_weekend():
    # Wed July 1 2026 + 3 business days -> Mon July 6 2026 (skips Sat/Sun)
    result = add_business_days(date(2026, 7, 1), 3)
    assert result == date(2026, 7, 6)


def test_add_business_days_skips_holiday():
    holidays = {date(2026, 7, 3)}
    # Wed July 1 + 2 business days, skipping Fri (holiday) and weekend -> Mon July 6
    result = add_business_days(date(2026, 7, 1), 2, holidays)
    assert result == date(2026, 7, 6)


def test_business_days_between_simple():
    # Mon to Fri same week = 4 business days elapsed
    assert business_days_between(date(2026, 7, 6), date(2026, 7, 10)) == 4


def test_business_days_between_across_weekend():
    # Fri to Mon = 1 business day elapsed (weekend doesn't count)
    assert business_days_between(date(2026, 7, 3), date(2026, 7, 6)) == 1


def test_find_overdue_items_threshold():
    items = [
        WatchedItem(item_id="1", entered_status_at=datetime(2026, 7, 1), context={}),  # 4 biz days ago from 7/7
        WatchedItem(item_id="2", entered_status_at=datetime(2026, 7, 6), context={}),  # 1 biz day ago
    ]
    now = datetime(2026, 7, 7)  # Tuesday
    overdue = find_overdue_items(items, threshold_business_days=3, now=now)
    assert len(overdue) == 1
    assert overdue[0].item.item_id == "1"
