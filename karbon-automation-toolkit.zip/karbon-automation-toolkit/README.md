# Karbon Automation Agent — Layer 1 Toolkit

Working scaffold of the Layer 1 (core toolkit) pieces described in the
technical spec. This is the workflow-agnostic plumbing: Karbon, Microsoft
Graph, Ignition, and Claude connectors, plus the generic escalation timer
engine. **Layer 2 (workflow-specific rules, checklists, template IDs) is
deliberately not built yet** — see `config/README.md`.

## What's here

```
karbon_toolkit/
  karbon_client.py     - Karbon API wrapper (work items, drafts, webhooks)
  graph_client.py       - Microsoft Graph calendar wrapper
  ignition_client.py    - Ignition webhook payload parsing + client matching
  claude_client.py      - Document completeness check + draft content generation
  scheduler.py           - Generic time-in-status escalation engine
  webhook_server.py     - FastAPI receiver wiring inbound webhooks to Layer 2 (stub)
tests/
  test_scheduler.py     - Business-day math tests (all passing)
config/
  README.md              - Placeholder + expected shape for Layer 2 config
```

## What's NOT here (on purpose)

- No Layer 2 rules, checklists, or template mappings — those depend on your
  finalized workflow redesign (see spec Sections 3 and 6).
- No real credentials — `.env.example` shows what's needed; nothing is wired
  to live Karbon/Graph/Ignition/Anthropic accounts.
- No webhook signature verification yet — needed before this goes anywhere
  near production, since these endpoints will receive client PII.
- Field names in `karbon_client.py`'s draft/scheduled-send methods and
  `ignition_client.py`'s payload parser are best-effort based on documented
  patterns, not verified against live API responses. **First thing your
  developer should do is fire a real test webhook/API call and confirm the
  actual field names match.**

## Setup

```bash
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env   # then fill in real values
pytest tests/          # confirms scheduler logic works before anything else
```

## Design principle carried through every file

Every function in `karbon_toolkit/` takes the "what" (status name, template
ID, checklist, threshold) as an argument rather than hardcoding it. That's
what makes this Layer 1: none of it should need to change when your
workflows get redesigned — only the Layer 2 config that calls into it will.

## Suggested next steps for your developer

1. Verify the Karbon API's actual field names for email drafts and scheduled
   send against a real sandbox call (the spec flags this as unconfirmed).
2. Confirm whether Karbon fires a webhook on attachment upload, or whether
   Workflow B needs a different trigger (spec Open Question #2).
3. Set up the Microsoft Graph app registration and decide between
   client-credentials vs. delegated auth, depending on whether calendar
   events should be created "as the app" or "as each preparer."
4. Add webhook signature verification to `webhook_server.py` before any
   real client data flows through it.
5. Once workflows are finalized, populate `config/` per the shapes shown
   in `config/README.md` and wire a rule dispatcher into
   `webhook_server.py`'s `register_handler` calls.
